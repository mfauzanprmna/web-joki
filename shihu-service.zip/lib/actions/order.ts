"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { calculateJokiItemLinePrice } from "@/lib/order-pricing";
import { computeRawatAkunPeriod, dateFromIsoDay, isoDay } from "@/lib/rawat-akun-schedule";
import { createUniqueCustomerSlug } from "./customer";
import { notifyOrderCreated, notifyOrderProgress } from "@/lib/discord-notify";
import { notifyOrderCreatedWA, notifyOrderProgressWA } from "@/lib/whatsapp-notify";
import { isPatchEventLive } from "@/lib/patch-schedule";

export interface OrderActionState {
  error?: string;
}

function generateOrderCode(usedCodes: Set<string>): string {
  let code: string;
  do {
    const n = Math.floor(10000 + Math.random() * 90000);
    code = `ECL-${n}`;
  } while (usedCodes.has(code));
  usedCodes.add(code);
  return code;
}

interface LineInputRaw {
  type: "item" | "paket" | "event" | "endgame";
  id: string;
  explorationPercent: number | null;
  actFrom: number | null;
  actTo: number | null;
  materialQuantity: number | null;
  rawatAkunQuantity: number | null;
  rawatAkunStartDate: string | null;
}

interface AccountInputRaw {
  accountId: string | null;
  accountName: string | null;
  accountUid: string | null;
  gameId: string;
  jokerName: string | null;
  estimasiJoki: string | null;
  lines: LineInputRaw[];
}

function parseLine(raw: unknown): LineInputRaw | { error: string } {
  if (
    typeof raw !== "object" ||
    raw === null ||
    (raw as { type?: unknown }).type == null ||
    (raw as { id?: unknown }).id == null
  ) {
    return { error: "Data baris order tidak valid." };
  }
  const e = raw as Record<string, unknown>;
  if (e.type !== "item" && e.type !== "paket" && e.type !== "event" && e.type !== "endgame") {
    return { error: "Data baris order tidak valid." };
  }
  return {
    type: e.type,
    id: String(e.id),
    explorationPercent: e.explorationPercent != null ? Number(e.explorationPercent) : null,
    actFrom: e.actFrom != null ? Number(e.actFrom) : null,
    actTo: e.actTo != null ? Number(e.actTo) : null,
    materialQuantity: e.materialQuantity != null ? Number(e.materialQuantity) : null,
    rawatAkunQuantity: e.rawatAkunQuantity != null ? Number(e.rawatAkunQuantity) : null,
    rawatAkunStartDate: e.rawatAkunStartDate ? String(e.rawatAkunStartDate) : null,
  };
}

/**
 * Parse & validasi field JSON "accountsJson" yang dikirim form: array akun,
 * masing-masing merepresentasikan satu tab/Order terpisah, dengan game dan
 * baris Joki Item/Paket sendiri-sendiri.
 */
function parseAccountsJson(formData: FormData): { accounts: AccountInputRaw[] } | { error: string } {
  const raw = String(formData.get("accountsJson") || "");
  if (!raw) {
    return { error: "Data akun tidak ditemukan." };
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return { error: "Data akun tidak valid." };
  }

  if (!Array.isArray(parsed) || parsed.length === 0) {
    return { error: "Isi minimal satu akun untuk order ini." };
  }

  const accounts: AccountInputRaw[] = [];
  for (const entry of parsed) {
    if (typeof entry !== "object" || entry === null) {
      return { error: "Data akun tidak valid." };
    }
    const e = entry as Record<string, unknown>;
    const gameId = String(e.gameId || "");
    const accountId = e.accountId ? String(e.accountId) : null;
    const accountName = e.accountName ? String(e.accountName).trim() || null : null;
    const accountUid = e.accountUid ? String(e.accountUid).trim() || null : null;
    if (!gameId) {
      return { error: "Setiap akun wajib memilih game." };
    }
    if (!accountId && !accountName) {
      return { error: "Setiap akun wajib memilih akun existing atau mengisi nama akun baru." };
    }
    if (!Array.isArray(e.lines) || e.lines.length === 0) {
      return { error: "Setiap akun wajib memilih minimal satu Joki Item atau Paket Joki." };
    }
    const lines: LineInputRaw[] = [];
    for (const rawLine of e.lines) {
      const parsedLine = parseLine(rawLine);
      if ("error" in parsedLine) {
        return { error: parsedLine.error };
      }
      lines.push(parsedLine);
    }
    accounts.push({
      accountId,
      accountName,
      accountUid,
      gameId,
      jokerName: e.jokerName ? String(e.jokerName).trim() || null : null,
      estimasiJoki: e.estimasiJoki ? String(e.estimasiJoki).trim() || null : null,
      lines,
    });
  }

  return { accounts };
}

export async function createOrder(
  _prevState: OrderActionState | undefined,
  formData: FormData
): Promise<OrderActionState> {
  const customerId = String(formData.get("customerId") || "").trim();
  const newCustomerName = String(formData.get("newCustomerName") || "").trim();

  if (!customerId && !newCustomerName) {
    return { error: "Pilih customer yang sudah ada, atau isi nama customer baru." };
  }

  const orderSource = String(formData.get("orderSource") || "") as
    | "DISCORD"
    | "INSTAGRAM"
    | "TIKTOK"
    | "WHATSAPP"
    | "";
  const sourceUsername = String(formData.get("sourceUsername") || "").trim();
  const sourceWhatsapp = String(formData.get("sourceWhatsapp") || "").trim();

  const validSources = ["DISCORD", "INSTAGRAM", "TIKTOK", "WHATSAPP"];
  if (!validSources.includes(orderSource)) {
    return { error: "Pilih tempat order (Discord/Instagram/TikTok/WhatsApp)." };
  }
  if (!sourceUsername) {
    return { error: "Username wajib diisi." };
  }
  if (orderSource === "WHATSAPP" && !sourceWhatsapp) {
    return { error: "Nomor WhatsApp wajib diisi untuk order dari WhatsApp." };
  }

  // Diskon bersifat OPSIONAL -- field kosong/tidak dikirim dianggap 0% (tidak
  // ada diskon), bukan error. Validasi ulang di sini (bukan cuma percaya
  // hitungan client) karena Server Action bisa dipanggil langsung.
  const discountPercentRaw = String(formData.get("discountPercent") || "").trim();
  const discountLabelRaw = String(formData.get("discountLabel") || "").trim();
  let discountPercent = 0;
  if (discountPercentRaw) {
    const parsed = Number(discountPercentRaw);
    if (Number.isNaN(parsed) || parsed < 0 || parsed > 100) {
      return { error: "Diskon harus berupa angka antara 0 dan 100." };
    }
    discountPercent = parsed;
  }

  const parsedAccounts = parseAccountsJson(formData);
  if ("error" in parsedAccounts) {
    return { error: parsedAccounts.error };
  }

  // Kumpulkan semua itemId/paketId dari SELURUH akun sekaligus, supaya cukup
  // satu query masing-masing (bukan per-akun berulang).
  const allItemIds = new Set<string>();
  const allPaketIds = new Set<string>();
  const allEventIds = new Set<string>();
  const allEndgameContentIds = new Set<string>();
  const allAccountIds = new Set<string>();
  for (const acc of parsedAccounts.accounts) {
    if (acc.accountId) allAccountIds.add(acc.accountId);
    for (const line of acc.lines) {
      if (line.type === "item") allItemIds.add(line.id);
      else if (line.type === "paket") allPaketIds.add(line.id);
      else if (line.type === "event") allEventIds.add(line.id);
      else allEndgameContentIds.add(line.id);
    }
  }

  const items =
    allItemIds.size > 0
      ? await prisma.jokiItem.findMany({
        where: { id: { in: Array.from(allItemIds) } },
        include: { category: true, patch: { select: { startDate: true, endDate: true } } },
      })
      : [];
  const pakets =
    allPaketIds.size > 0
      ? await prisma.jokiPaket.findMany({
        where: { id: { in: Array.from(allPaketIds) } },
        include: {
          items: {
            include: {
              jokiItem: {
                select: {
                  id: true,
                  actNumber: true,
                  category: { select: { requiresQuestType: true, isRawatAkun: true } },
                  isPatchWide: true,
                  durationDays: true,
                  patch: { select: { startDate: true, endDate: true } },
                },
              },
            },
          },
        },
      })
      : [];
  const events =
    allEventIds.size > 0
      ? await prisma.patchEvent.findMany({
        where: { id: { in: Array.from(allEventIds) } },
        include: { patch: { select: { gameId: true } } },
      })
      : [];
  const endgameContents =
    allEndgameContentIds.size > 0
      ? await prisma.endgameContent.findMany({
        where: { id: { in: Array.from(allEndgameContentIds) }, isActive: true, isOrderable: true },
      })
      : [];
  const existingAccounts =
    allAccountIds.size > 0 && customerId
      ? await prisma.jokiAccount.findMany({
        where: { id: { in: Array.from(allAccountIds) }, customerId },
        select: { id: true, gameId: true },
      })
      : [];

  const itemMap = new Map(items.map((i) => [i.id, i]));
  const paketMap = new Map(pakets.map((p) => [p.id, p]));
  const eventMap = new Map(events.map((event) => [event.id, event]));
  const endgameContentMap = new Map(endgameContents.map((content) => [content.id, content]));
  const accountMap = new Map(existingAccounts.map((account) => [account.id, account]));

  for (const acc of parsedAccounts.accounts) {
    if (acc.accountId) {
      const account = accountMap.get(acc.accountId);
      if (!account) return { error: "Akun yang dipilih tidak ditemukan untuk customer ini." };
      if (account.gameId !== acc.gameId) return { error: "Akun yang dipilih tidak sesuai dengan game akun ini." };
    }
  }

  interface ResolvedAccount {
    accountId: string | null;
    accountName: string | null;
    accountUid: string | null;
    gameId: string;
    jokerName: string | null;
    estimasiJoki: string | null;
    totalPrice: number;
    /// Nominal potongan diskon untuk akun ini (0 kalau tidak ada diskon).
    /// Diisi SETELAH loop resolve selesai -- lihat kode setelah loop utama.
    discountAmount: number;
    lines: {
      jokiItemId: string | null;
      jokiPaketId: string | null;
      paketGroupId: string | null;
      patchEventId: string | null;
      endgameContentId: string | null;
      explorationPercent: number | null;
      actFrom: number | null;
      actTo: number | null;
      materialQuantity: number | null;
      rawatAkunQuantity: number | null;
      startDate: Date | null;
      endDate: Date | null;
      calculatedPrice: number;
    }[];
  }

  const resolvedAccounts: ResolvedAccount[] = [];

  for (const acc of parsedAccounts.accounts) {
    const linesToCreate: ResolvedAccount["lines"] = [];

    for (const line of acc.lines) {
      if (line.type === "item") {
        const item = itemMap.get(line.id);
        if (!item) {
          return { error: "Salah satu Joki Item yang dipilih tidak ditemukan." };
        }
        const result = calculateJokiItemLinePrice(item, line);
        if (!result.valid) {
          return { error: `${item.title}: ${result.error}` };
        }

        let startDate: Date | null = null;
        let endDate: Date | null = null;
        if (item.category.isRawatAkun) {
          const quantity = line.rawatAkunQuantity ?? 1;
          const requestedStart = line.rawatAkunStartDate
            ? dateFromIsoDay(line.rawatAkunStartDate)
            : dateFromIsoDay(isoDay(new Date()));
          const period = computeRawatAkunPeriod(
            { isPatchWide: item.isPatchWide, durationDays: item.durationDays, patch: item.patch },
            quantity,
            requestedStart
          );
          if (!period) {
            return {
              error: `${item.title}: durasi (hari) Joki Item ini belum diisi, tidak bisa menghitung tanggal selesai.`,
            };
          }
          startDate = period.startDate;
          endDate = period.endDate;
        }

        linesToCreate.push({
          jokiItemId: item.id,
          jokiPaketId: null,
          paketGroupId: null,
          patchEventId: null,
          endgameContentId: null,
          explorationPercent: line.explorationPercent,
          actFrom: line.actFrom,
          actTo: line.actTo,
          materialQuantity: line.materialQuantity,
          rawatAkunQuantity: line.rawatAkunQuantity,
          startDate,
          endDate,
          calculatedPrice: result.price,
        });
      } else if (line.type === "paket") {
        const paket = paketMap.get(line.id);
        if (!paket) {
          return { error: "Salah satu Paket Joki yang dipilih tidak ditemukan." };
        }
        if (paket.items.length === 0) {
          return { error: `Paket "${paket.title}" belum punya isi Joki Item sama sekali.` };
        }

        // Satu OrderLine PER Joki Item isi paket (bukan satu OrderLine
        // gabungan untuk seluruh paket) -- supaya progress tiap item
        // (persen, update, screenshot, status selesai) tersimpan & bisa
        // diisi terpisah. paketGroupId menandai semua baris ini berasal
        // dari SATU kali pembelian paket yang sama, supaya tetap tampil
        // sebagai satu tab "Paket X" di halaman update progress.
        const paketGroupId = crypto.randomUUID();

        for (const [index, paketItem] of paket.items.entries()) {
          const isRawatAkun = paketItem.jokiItem.category.isRawatAkun;

          let startDate: Date | null = null;
          let endDate: Date | null = null;
          if (isRawatAkun) {
            // Item Rawat Akun di dalam paket dihitung durasinya sama seperti
            // item Rawat Akun berdiri sendiri: mulai hari ini, 1x durasi
            // default (paket tidak punya input jumlah/tanggal mulai sendiri
            // dari form, karena harga paket sudah flat per 1 paket).
            const period = computeRawatAkunPeriod(
              {
                isPatchWide: paketItem.jokiItem.isPatchWide,
                durationDays: paketItem.jokiItem.durationDays,
                patch: paketItem.jokiItem.patch,
              },
              1,
              dateFromIsoDay(isoDay(new Date()))
            );
            if (period) {
              startDate = period.startDate;
              endDate = period.endDate;
            }
            // Kalau durasi belum diisi di Joki Item-nya, biarkan startDate/
            // endDate null (sama seperti kalau JokiPaketItem lain gagal
            // hitung durasi) -- baris ini tetap tersimpan, cuma kalender
            // Rawat Akun-nya tidak otomatis terbentuk sampai admin
            // melengkapi durationDays Joki Item tsb.
          }

          linesToCreate.push({
            jokiItemId: paketItem.jokiItemId,
            jokiPaketId: paket.id,
            paketGroupId,
            patchEventId: null,
            endgameContentId: null,
            explorationPercent: null,
            actFrom: paketItem.actFrom,
            actTo: paketItem.actTo,
            materialQuantity: null,
            rawatAkunQuantity: null,
            startDate,
            endDate,
            // Harga paket adalah 1 harga borongan, bukan per item -- taruh
            // semuanya di baris PERTAMA supaya total order tetap benar
            // (SUM(calculatedPrice) semua baris = harga paket), sisanya 0.
            // Harga per item TIDAK ditampilkan di mana pun (lihat
            // describeLine di OrderRowItem.tsx) supaya tidak menyesatkan.
            calculatedPrice: index === 0 ? paket.priceRupiah : 0,
          });
        }
      } else if (line.type === "event") {
        const event = eventMap.get(line.id);
        if (!event || !isPatchEventLive(event)) {
          return { error: "Salah satu event yang dipilih sudah tidak sedang berjalan." };
        }
        if (event.patch.gameId !== acc.gameId) {
          return { error: "Event yang dipilih tidak sesuai dengan game akun ini." };
        }
        linesToCreate.push({
          jokiItemId: null,
          jokiPaketId: null,
          paketGroupId: null,
          patchEventId: event.id,
          endgameContentId: null,
          explorationPercent: null,
          actFrom: null,
          actTo: null,
          materialQuantity: null,
          rawatAkunQuantity: null,
          startDate: null,
          endDate: null,
          calculatedPrice: event.priceRupiah,
        });
      } else {
        const content = endgameContentMap.get(line.id);
        if (!content) {
          return { error: "Salah satu konten endgame tidak ditemukan atau sedang tidak tersedia." };
        }
        if (content.gameId !== acc.gameId) {
          return { error: "Konten endgame yang dipilih tidak sesuai dengan game akun ini." };
        }
        linesToCreate.push({
          jokiItemId: null,
          jokiPaketId: null,
          paketGroupId: null,
          patchEventId: null,
          endgameContentId: content.id,
          explorationPercent: null,
          actFrom: null,
          actTo: null,
          materialQuantity: null,
          rawatAkunQuantity: null,
          startDate: null,
          endDate: null,
          calculatedPrice: content.priceRupiah,
        });
      }
    }

    resolvedAccounts.push({
      accountId: acc.accountId,
      accountName: acc.accountName,
      accountUid: acc.accountUid,
      gameId: acc.gameId,
      jokerName: acc.jokerName,
      estimasiJoki: acc.estimasiJoki,
      totalPrice: linesToCreate.reduce((sum, l) => sum + l.calculatedPrice, 0),
      discountAmount: 0, // diisi setelah loop ini selesai, lihat di bawah
      lines: linesToCreate,
    });
  }

  // Terapkan diskon (kalau ada) SETELAH semua akun selesai di-resolve, supaya
  // proporsi tiap akun dihitung terhadap subtotal keseluruhan pesanan --
  // bukan dibagi rata flat, jadi akun dengan harga lebih besar mendapat
  // potongan nominal yang sebanding lebih besar juga. Logika ini SENGAJA
  // sama persis dengan pratinjau di CreateOrderForm.tsx (accountDiscountAmount)
  // supaya angka yang admin lihat di modal konfirmasi = angka yang tersimpan.
  const subtotalAllAccounts = resolvedAccounts.reduce((sum, a) => sum + a.totalPrice, 0);
  if (subtotalAllAccounts > 0 && discountPercent > 0) {
    for (const acc of resolvedAccounts) {
      const originalPrice = acc.totalPrice;
      acc.discountAmount = Math.round((originalPrice * discountPercent) / 100);
      acc.totalPrice = originalPrice - acc.discountAmount; // jadi harga FINAL
    }
  }

  // Generate publicSlug DI LUAR transaksi (butuh query findUnique tersendiri
  // untuk memastikan keunikan) -- hanya diperlukan kalau customer baru dibuat.
  const newCustomerSlug = !customerId ? await createUniqueCustomerSlug() : null;

  // Kumpulkan info tiap akun yang berhasil dibuat, dipakai untuk notifikasi
  // Discord SETELAH transaksi commit (supaya tidak ada notif untuk order
  // yang ternyata gagal tersimpan).
  const createdForNotify: {
    orderCode: string;
    gameId: string;
    layanan: string;
    totalPrice: number;
  }[] = [];

  // Semua akun (Order) dibuat dalam satu transaksi: kalau salah satu akun
  // gagal (mis. constraint DB), tidak ada Order yang tersimpan setengah-setengah.
  const usedCodes = new Set<string>();
  let resolvedCustomerId = "";
  await prisma.$transaction(async (tx) => {
    resolvedCustomerId =
      customerId ||
      (
        await tx.customer.create({
          data: { name: newCustomerName, publicSlug: newCustomerSlug! },
        })
      ).id;

    for (const acc of resolvedAccounts) {
      const orderCode = generateOrderCode(usedCodes);
      const accountId = acc.accountId ?? (await tx.jokiAccount.create({
        data: {
          customerId: resolvedCustomerId,
          gameId: acc.gameId,
          name: acc.accountName!,
          uid: acc.accountUid,
        },
        select: { id: true },
      })).id;
      await tx.order.create({
        data: {
          orderCode,
          gameId: acc.gameId,
          customerId: resolvedCustomerId,
          accountId,
          jokerName: acc.jokerName,
          estimasiJoki: acc.estimasiJoki,
          status: "MENUNGGU",
          progressPct: 0,
          totalPrice: acc.totalPrice,
          discountPercent: acc.discountAmount > 0 ? discountPercent : null,
          discountAmount: acc.discountAmount > 0 ? acc.discountAmount : null,
          discountLabel: acc.discountAmount > 0 && discountLabelRaw ? discountLabelRaw : null,
          orderSource: orderSource as "DISCORD" | "INSTAGRAM" | "TIKTOK" | "WHATSAPP",
          sourceUsername,
          sourceWhatsapp: orderSource === "WHATSAPP" ? sourceWhatsapp : null,
          lines: { create: acc.lines },
        },
      });

      const seenPaketGroups = new Set<string>();
      createdForNotify.push({
        orderCode,
        gameId: acc.gameId,
        layanan: acc.lines
          .map((l) => {
            // Cek jokiPaketId LEBIH DULU (bukan jokiItemId) -- baris hasil
            // pecahan satu pembelian Paket punya KEDUANYA terisi, tapi yang
            // relevan untuk notifikasi adalah nama PAKET-nya (satu kali),
            // bukan nama tiap Joki Item isinya (akan berulang N kali kalau
            // dicek jokiItemId duluan, dan itemMap juga tidak mengenal id
            // Joki Item yang berasal dari isi paket).
            if (l.jokiPaketId) {
              const groupKey = l.paketGroupId ?? l.jokiPaketId;
              if (seenPaketGroups.has(groupKey)) return null;
              seenPaketGroups.add(groupKey);
              return paketMap.get(l.jokiPaketId)?.title ?? null;
            }
            if (l.jokiItemId) return itemMap.get(l.jokiItemId)?.title ?? null;
            if (l.patchEventId) return eventMap.get(l.patchEventId)?.title ?? null;
            if (l.endgameContentId) return endgameContentMap.get(l.endgameContentId)?.title ?? null;
            return null;
          })
          .filter((title): title is string => !!title)
          .join(", ") || "Pesanan kustom",
        totalPrice: acc.totalPrice,
      });
    }
  });

  revalidatePath("/admin/antrian");
  revalidatePath("/admin/customer");
  revalidatePath("/antrian");
  revalidatePath("/history");

  // Notifikasi Discord & WhatsApp dikirim TERPISAH dari transaksi DB di atas
  // (fire-and-forget, lihat lib/discord-notify.ts & lib/whatsapp-notify.ts)
  // -- kalau bot/provider down, order tetap sukses dibuat, cuma notifnya
  // yang tidak terkirim.
  if (createdForNotify.length > 0) {
    const [customer, games] = await Promise.all([
      prisma.customer.findUnique({
        where: { id: resolvedCustomerId },
        select: { name: true, publicSlug: true, whatsappNumber: true, whatsappNotifEnabled: true },
      }),
      prisma.game.findMany({
        where: { id: { in: createdForNotify.map((c) => c.gameId) } },
        select: { id: true, name: true },
      }),
    ]);
    const gameNameById = new Map(games.map((g) => [g.id, g.name]));

    if (customer) {
      for (const created of createdForNotify) {
        notifyOrderCreated({
          orderCode: created.orderCode,
          customerName: customer.name,
          gameName: gameNameById.get(created.gameId) ?? "-",
          layanan: created.layanan,
          totalPrice: created.totalPrice,
          status: "MENUNGGU",
          publicSlug: customer.publicSlug,
        });
        notifyOrderCreatedWA({
          customer,
          customerName: customer.name,
          orderCode: created.orderCode,
          gameName: gameNameById.get(created.gameId) ?? "-",
          layanan: created.layanan,
          totalPrice: created.totalPrice,
          publicSlug: customer.publicSlug,
        });
      }
    }
  }

  return {};
}

export async function updateOrder(formData: FormData) {
  const id = String(formData.get("id"));
  const jokerName = String(formData.get("jokerName") || "").trim();
  const status = String(formData.get("status"));
  const progressPct = Number(formData.get("progressPct"));
  const estimasiJoki = String(formData.get("estimasiJoki") || "").trim();

  const data: {
    jokerName: string | null;
    status: "MENUNGGU" | "DIKERJAKAN" | "FINISHING" | "SELESAI" | "DIBATALKAN";
    progressPct: number;
    estimasiJoki: string | null;
    completedAt?: Date;
  } = {
    jokerName: jokerName || null,
    status: status as "MENUNGGU" | "DIKERJAKAN" | "FINISHING" | "SELESAI" | "DIBATALKAN",
    progressPct,
    estimasiJoki: estimasiJoki || null,
  };

  if (status === "SELESAI") {
    data.completedAt = new Date();
    data.progressPct = 100;
  }

  const updated = await prisma.order.update({
    where: { id },
    data,
    select: {
      orderCode: true,
      status: true,
      progressPct: true,
      customer: {
        select: { name: true, publicSlug: true, whatsappNumber: true, whatsappNotifEnabled: true },
      },
    },
  });

  revalidatePath("/admin/antrian");
  revalidatePath("/antrian");
  revalidatePath("/history");

  // Fire-and-forget: kirim update progress/status ke Discord & WhatsApp
  // (lihat catatan di lib/discord-notify.ts & lib/whatsapp-notify.ts --
  // tidak akan menggagalkan update ini kalau bot/provider sedang tidak bisa
  // dihubungi).
  notifyOrderProgress({
    orderCode: updated.orderCode,
    status: updated.status,
    progressPct: updated.progressPct,
    publicSlug: updated.customer.publicSlug,
  });
  notifyOrderProgressWA({
    customer: updated.customer,
    customerName: updated.customer.name,
    orderCode: updated.orderCode,
    status: updated.status,
    progressPct: updated.progressPct,
    publicSlug: updated.customer.publicSlug,
  });
}

export async function deleteOrder(formData: FormData) {
  const id = String(formData.get("id"));
  await prisma.order.delete({ where: { id } });

  revalidatePath("/admin/antrian");
  revalidatePath("/antrian");
  revalidatePath("/history");
}
